/**
 * Artem Amarbeiev.
 * <p>
 * Copyright (c) 2021 Artem Amarbeiev. All Rights Reserved.
 */
package org.example;

import java.io.IOException;
import java.util.Comparator;
import java.util.List;
import java.util.Random;
import java.util.stream.Collectors;
import java.util.stream.IntStream;

/**
 * SeaShipSorter. Implementation of forth laboratory work.
 *
 * @version 1.0 11 Dec 2021
 * @author Artem Amarbeiev
 */
public class SeaShipSorter {

	/**
	 * Main executive method.
	 *
	 * @throws IOException throws when resource with text isn't represented.
	 * @param args Arguments from command line.
	 */
	public static void main(String[] args) {
		/** SeaShipSorter instance. */
		final SeaShipSorter seaShipSorter = new SeaShipSorter();
		/** List with random SeaShip objects. */
		final List<SeaShip> ships = seaShipSorter.generateSeaShipsList(7);

		System.out.println("Sort by year of release:");
		seaShipSorter.sortSeaShipsByYearOfRelease(ships)
			.forEach(System.out::println);

		System.out.println("\nSort by width:");
		seaShipSorter.sortSeaShipsByWidth(ships)
			.forEach(System.out::println);
	}

	/**
	 * Generate list with SeaShip objects with random fields.
	 *
	 * @param count SeaShip objects count.
	 * @return List with SeaShip objects.
	 */
	private List<SeaShip> generateSeaShipsList(int count) {
		return IntStream.range(0, count)
			.mapToObj(i -> generateSeaShip())
			.collect(Collectors.toList());
	}

	/**
	 * Generate SeaShip object with random fields.
	 *
	 * @return SeaShip object.
	 */
	private SeaShip generateSeaShip() {
		/** List of common ships names. */
		List<String> names = List.of("Battleship", "Corvette", "Cruiser",
			"Destroyer", "Frigate", "Galleon", "Ironclad");

		return new SeaShip(
			names.get(new Random().nextInt(names.size())) + '-'
				+ names.get(new Random().nextInt(names.size())),
			1900 + new Random().nextInt(100),
			100 + new Random().nextInt(100),
			20 + new Random().nextInt(30),
			15 + new Random().nextInt(25)
		);
	}

	/**
	 * Sort list with sea ships by their widths.
	 *
	 * @param ships List with SeaShip objects, that should be sorted.
	 * @return Sorted list with SeaShip objects.
	 */
	private List<SeaShip> sortSeaShipsByWidth(List<SeaShip> ships) {
		return ships.stream()
			.sorted((ship1, ship2) -> ship2.width() > ship1.width() ? 1 : -1)
			.collect(Collectors.toList());
	}

	/**
	 * Sort list with sea ships by their years of release.
	 *
	 * @param ships List with SeaShip objects, that should be sorted.
	 * @return Sorted list with SeaShip objects.
	 */
	private List<SeaShip> sortSeaShipsByYearOfRelease(List<SeaShip> ships) {
		return ships.stream()
			.sorted(Comparator.comparingInt(SeaShip::yearOfRelease))
			.collect(Collectors.toList());
	}
}
