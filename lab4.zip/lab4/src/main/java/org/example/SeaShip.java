/**
 * Artem Amarbeiev.
 * <p>
 * Copyright (c) 2021 Artem Amarbeiev. All Rights Reserved.
 */
package org.example;

import java.util.StringJoiner;

/**
 * SeaShip. Representation of sea ship.
 *
 * @version 1.0 11 Dec 2021
 * @author Artem Amarbeiev
 */
public class SeaShip {

	/** Ship's name. */
	private final String name;
	/** Ship's year of release. */
	private final int yearOfRelease;
	/** Ship's length. */
	private final int length;
	/** Ship's width. */
	private final int width;
	/** Ship's height. */
	private final int height;

	/**
	 * SeaShip constructor.
	 *
	 * @param name Ship's name
	 * @param yearOfRelease Ship's year of release
	 * @param length Ship's length
	 * @param width Ship's width
	 * @param height Ship's height
	 */
	public SeaShip(String name, int yearOfRelease, int length, int width, int height) {
		this.name = name;
		this.yearOfRelease = yearOfRelease;
		this.length = length;
		this.width = width;
		this.height = height;
	}

	/**
	 * Getter for ship's name.
	 * @return ship's name
	 */
	public String name() {
		return name;
	}

	/**
	 * Getter for ship's year of release.
	 * @return ship's year of release
	 */
	public int yearOfRelease() {
		return yearOfRelease;
	}

	/**
	 * Getter for ship's length.
	 * @return ship's name
	 */
	public int length() {
		return length;
	}

	/**
	 * Getter for ship's width.
	 * @return ship's width
	 */
	public int width() {
		return width;
	}

	/**
	 * Getter for ship's height.
	 * @return ship's height
	 */
	public int height() {
		return height;
	}

	/**
	 * Method for convert SeaShip object to string.
	 * @return String representation of SeaShip object.
	 */
	@Override
	public String toString() {
		return new StringJoiner(", ",  name + " {", " }")
			.add(String.format("yearOfRelease = {%s}", yearOfRelease))
			.add(String.format("length = {%s}", length))
			.add(String.format("width = {%s}", width))
			.add(String.format("height = {%s}", height))
			.toString();
	}
}
