/**
 * Artem Amarbeiev.
 * <p>
 * Copyright (c) 2021 Artem Amarbeiev. All Rights Reserved.
 */
package org.example;

import java.io.IOException;
import java.util.Arrays;
import java.util.Comparator;
import java.util.List;
import java.util.stream.Collectors;

/**
 * WordsSorter. Implementation of third laboratory work.
 *
 * @version 1.0 11 Dec 2021
 * @author Artem Amarbeiev
 */
public class WordsSorter {
	/** List of vowels letters. */
	private static List<Character> vowels;
	/** String with text example */
	private static String textExample;

	/**
	 * Main executive method.
	 *
	 * @throws IOException throws when resource with text isn't represented.
	 * @param args Arguments from command line.
	 */
	public static void main(String[] args) throws IOException {
		vowels = List.of('a', 'e', 'i', 'o', 'u');
		textExample = "Apart from the cost, shared flats and houses are often "
			+ "in poor condition. Landlords are slow to spend their "
			+ "profits on repairs. I was fairly lucky with mine. "
			+ "The house I lived in was scruffy, but the landlord "
			+ "took action when needed — like the time the bathroom ceiling "
			+ "fell in. I'd just run a bath and had returned to my room to "
			+ "get something, when I heard a loud crash. I went back to find "
			+ "the bathtub full of wet plaster. I had the ceiling repaired "
			+ "and took the bill to my landlord.";

		System.out.println(sortWordsByVowelsCount(textExample));
	}

	/**
	 * Parse all words from text and sort it by vowels letters count.
	 *
	 * @param text Text, from which method should parse and sort words.
	 * @return Joined by space, sorted list of words.
	 */
	private static String sortWordsByVowelsCount(String text) {
		return Arrays.stream(text.split("\\s|\\.|,|-|—"))
			.filter(word -> !word.isEmpty())
			.sorted(Comparator.comparingInt(WordsSorter::getVowelsCount))
			.collect(Collectors.joining(" "));
	}

	/**
	 * Count vowels letters in word.
	 *
	 * @param word Word in which should count vowels.
	 * @return Vowels letters count.
	 */
	private static int getVowelsCount(String word) {
		return (int) word.chars()
			.mapToObj(i -> (char) i)
			.filter(vowels::contains)
			.count();
	}
}
